						READ FIRST:

						How TO:
unzip with your priority_queue.c source code

put this in your terminal (when you inside current directory):

make
make run
make runVLG

THATS IT!

every time you want to edit your .c file you need to write this 3 lines again
for re-compiling

						NOTICE:
- 	when "runVLG", one error occur no matter if your code is wowrking or not.
	"==31637== Argument 'size' of function malloc has a fishy (possibly negative) value: -1"
	it is yelling because one malloc test. 

-	some tests may fail and literly paint you command line - it is ok.
	fix it by restart your terminal (CTRL+D usually work)

- 	most of the tests make use of other PQ functions, 
	like Contain test tha use RemoveElem.
	keep that in mind

-	pq_test.c is the test file.
	you can use it to search where test failed.
	you cannot compile this file because missing relevant header file
	
						TEST:
/******************************************************************************
	Tasks:
	[x] NullArgs		- all functions with every NULL arg
	[x] CreateDestroy	- empty pq, double destroy, normal case
	[x] Copy			- empty pq, normal case
	[x] Size			- empty pq, normal case
	[x] Contains		- empty pq, elem not exist, elem exist
	[x] Insert			- Malloc fail, normal case
	[x] ChangePrio		- FIRST elem changed, re-insert, Malloc fail, normal case
	[x] Remove			- empty pq, first inserted
	[x] RemoveElem		- empty pq, FIRST elem changed, doesnt exist
	[x] IteratorTests	- empty pq, same priorities, next after invalid, invalid inside loop, nested loop
	[x] Clear			- empty pq
******************************************************************************/
						EXPECTED OUTPUT:

 NULL Args Test Begin: 
1)       Test pqCopy                            TRUE!
2)       Test pqGetSize                         TRUE!
3)       Test pqContains                        TRUE!
4)       Test pqContains                        TRUE!
5)       Test pqInsert                          TRUE!
6)       Test pqInsert                          TRUE!
7)       Test pqInsert                          TRUE!
8)       Test pqChangePriority                  TRUE!
9)       Test pqChangePriority                  TRUE!
10)      Test pqChangePriority                  TRUE!
11)      Test pqChangePriority                  TRUE!
12)      Test pqRemove                          TRUE!
13)      Test pqRemoveElement                   TRUE!
14)      Test pqRemoveElement                   TRUE!
15)      Test pqGetFirst                        TRUE!
16)      Test pqGetNext                         TRUE!
17)      Test pqClear                           TRUE!
 NULL Args Test END 
 Create Destroy Test Begin: 
 Create Destroy Test END 
 Copy Test Begin: 
1)       Test Empty PQ                          TRUE!
2)       Test Normal Case                       TRUE!
 Copy Test End 
 Size Test Begin: 
1)       Test Empty PQ                          TRUE!
2)       Test Normal Case                       TRUE!
 Size Test End 
 Contain Test Begin: 
1)       Test Empty PQ                          TRUE!
2)       Test Elem Not Found                    TRUE!
3)       Test Duplicate Elems                   TRUE!
 Contain Test End 
 Insert Test Begin: 
1)       Test Normal Case 1                     TRUE!
2)       Test Normal Case 2                     TRUE!
3)       Test Normal Case 3                     TRUE!
4)       Test Malloc Fail                       TRUE!
 Insert Test End 
 ChangePrio Test Begin: 
1)       Test Empty PQ                          TRUE!
2)       Test Normal Case                       TRUE!
3)       Test Flip PQ                           TRUE!
4)       Test dif prio                          TRUE!
5)       Test Single elem                       TRUE!
 ChangePrio Test End 
 Remove Test Begin: 
1)       Test Empty PQ1                         TRUE!
2)       Test Empty PQ2                         TRUE!
3)       Test Normal Case                       TRUE!
 Remove Test End 
 RemoveElem Test Begin: 
1)       Test Empty PQ                          TRUE!
2)       Test Normal Case                       TRUE!
3)       Test Elem Not Exist1                   TRUE!
4)       Test Elem Not Exist2                   TRUE!
 RemoveElem Test End 
 Iterator Test Begin: 
1)       Test Empty PQ-getfirst                         TRUE!
2)       Test Empty PQ-getnext                          TRUE!
3)       Test Invalid iter                              TRUE!
4)       Test Invalid iter-copy1                        TRUE!
5)       Test Invalid iter-copy2                        TRUE!
6)       Test Invalid iter-changePrio                   TRUE!
7)       Test Invalid iter-Remove                       TRUE!
8)       Test Invalid iter-RemoveElem                   TRUE!
9)       Test Iterating                                 TRUE!
 Iterator Test End 
 Clear Test Begin: 
1)       Test Empty PQ                          TRUE!
2)       Test Normal Case                       TRUE!
 Clear Test End 